# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from odoo import models, fields, api, _

class CustType(models.Model):
    _name = 'cust.type'
    _description = 'Customer Type'

    name = fields.Char(string="Name")

class StnDurasi(models.Model):
    _name = 'stn.durasi'
    _description = 'Satuan Durasi'

    name = fields.Char(string="Name")

class CustCust(models.Model):
    _name = 'cust.cust'
    _description = 'Customer'

    name = fields.Char(string="Name")
    description = fields.Char(string="Description")

class LokDoc(models.Model):
    _name = 'lok.doc'
    _description = 'Lokasi Docking'

    name = fields.Char(string="Name")
    description = fields.Char(string="Description")

class JenisDok(models.Model):
    _name = 'jenis.dok'
    _description = 'Jenis Dokumen'

    name = fields.Char(string="Name")
    description = fields.Char(string="Description")

class StatusOpp(models.Model):
    _name = 'status.opp'
    _description = 'Status Opportunity'

    name = fields.Char(string="Name")
    description = fields.Char(string="Description")

class Priority(models.Model):
    _name = 'priority.priority'
    _description = 'Priority'

    name = fields.Char(string="Name")
    description = fields.Char(string="Description")

class StatusPeng(models.Model):
    _name = 'status.peng'
    _description = 'Status Pengadaan'

    name = fields.Char(string="Name")
    description = fields.Char(string="Description")

class MetodeMetode(models.Model):
    _name = 'metode.metode'
    _description = 'Metode'

    name = fields.Char(string="Name")
    description = fields.Char(string="Description")