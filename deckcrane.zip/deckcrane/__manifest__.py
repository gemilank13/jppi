# -*- coding: utf-8 -*-
{
    'name': "JPPI - DECKCRANE",

    'summary': """
       """,

    'description': """
        
    """,

    'author': "PT JPPI - Geger Gemilank",
    'website': "http://www.jppi.co.id",
    'category': 'Uncategorized',
    'version': '0.1',

    'depends': ['base'],

    'data': [
        'security/ir.model.access.csv',
        # 'views/menuitem.xml',
        'views/config.xml',
    ],
    
    'demo': [],
}